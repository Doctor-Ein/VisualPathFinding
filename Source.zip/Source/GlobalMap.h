#ifndef GLOBALS_H
#define GLOBALS_H

#include "Map.h"

extern Map globalMap;

#endif // GLOBALS_H